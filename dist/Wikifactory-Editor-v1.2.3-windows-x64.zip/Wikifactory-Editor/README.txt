Wikifactory Editor v1.2.3（Windows x64 便携版）

1. 解压后双击 Wikifactory-Editor.exe 运行。
2. Wikifactory-Editor.exe 必须与 resources.neu 放在同一目录；缺少 resources.neu 会无法启动。
3. 需要 Microsoft Edge WebView2 Runtime（Windows 10/11 通常自带）。
   若提示缺少运行库：https://go.microsoft.com/fwlink/p/?LinkId=2124703
4. 若从浏览器下载后无法运行：右键 exe → 属性 → 勾选「解除锁定」→ 确定。
5. 启动失败时，同目录下会生成 neutralinojs.log，可据此排查（常见原因是杀毒软件拦截或缺少 WebView2）。

本 exe 使用 Wikifactory Editor 自签名证书签名；签名可在「文件属性 → 数字签名」中查看。

https://github.com/hellokug2699/Wikifactory-Editor